import React, { Component } from 'react';

class MyComponent extends Component {
  constructor(props) {
    alert("1");
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
      items: null
    };
  }

  componentDidMount() {
    alert("2");
    fetch("http://in11022176lt:3000/api/Manufacturer")
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({
            isLoaded: true,
            items: result.$class
          });
        },
        // Note: it's important to handle errors here
        // instead of a catch() block so that we don't swallow
        // exceptions from actual bugs in components.
        (error) => {
          this.setState({
            isLoaded: true,
            error
          });
        }
      )
  }

  render() {
    alert("1");
    const { error, isLoaded, items } = this.state;
    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
        <ul>
          {
            <li key={items}>
              {items} {items}
            </li>
          }
        </ul>
      );
    }
  }
}

export default MyComponent;