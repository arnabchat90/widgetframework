import React, { PropTypes } from 'react';
import { Button,FormGroup,PageHeader,FormControl, ControlLabel,HelpBlock} from 'react-bootstrap';
import 'whatwg-fetch';

const title = 'Order Page';

// function displayBlank(props, context) {
//   context.setTitle(title);
//   return (
//     <div>
//       <div className="row">
//         <div className="col-lg-12">
//           <PageHeader>Order Page</PageHeader>
//           <form>

//           </form>
//         </div>
//       </div>
//     </div>
//   );
// }

class displayBlank extends React.Component {
  constructor(props, context) {
    super(props, context);

    this.handleOrderIdChange = this.handleOrderIdChange.bind(this);
    this.handleSupplierIdChange = this.handleSupplierIdChange.bind(this);
    this.handleODChange = this.handleODChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);

    this.state = {
      orderId: '',
      supplierId : '',
      orderDesc : ''
    };
  }

  onSubmit() {
    //testing get
  //   fetch('http://localhost:5005/orders')
  // .then(function(response) {
  //   return response.json()
  // }).then(function(json) {
  //   console.log('parsed json', json)
  // }).catch(function(ex) {
  //   console.log('parsing failed', ex)
  // })
  //posting order data
  fetch('http://localhost:5005/orders', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: this.state
  })
  }

  getValidationState() {
    const length = this.state.orderId.length;
    if (length > 10) return 'success';
    else if (length > 5) return 'warning';
    else if (length > 0) return 'error';
    return null;
  }

  handleOrderIdChange(e) {
    this.setState({ orderId: e.target.value });
  }
  handleSupplierIdChange(e) {
    this.setState({ supplierId: e.target.value });
  }
  handleODChange(e) {
    this.setState({ orderDesc: e.target.value });
  }

  render() {
    return (
      <div>
      <div className="row">
        <PageHeader>Order Page</PageHeader>
      </div>
      <div className="row">
      <div className="col-md-6">
      <form>
        <FormGroup
          controlId="formBasicText"
          validationState={this.getValidationState()}
        >
          <ControlLabel>Order Id</ControlLabel>
          <FormControl
            id="orderid"
            type="text"
            value={this.state.orderId}
            placeholder="Enter text"
            onChange={this.handleOrderIdChange}
          />
          <br />
          <ControlLabel>Supplier Id</ControlLabel>
          <FormControl
            id="supplierid"
            type="text"
            value={this.state.supplierId}
            placeholder="Enter text"
            onChange={this.handleSupplierIdChange}
          />
          <br />
          <ControlLabel>Order Description</ControlLabel>
          <FormControl
            id="orderdesc"
            type="text"
            value={this.state.orderDesc}
            placeholder="Enter text"
            onChange={this.handleODChange}
          />
          <br />
          <FormControl.Feedback />
          <br />
          <Button bsStyle="primary" onClick={this.onSubmit}>Submit</Button>
        </FormGroup>
      </form>
      </div>
      </div>
      </div>
    );
  }
}



// displayBlank.contextTypes = { setTitle: PropTypes.func.isRequired };
export default displayBlank;
