/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-2016 Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React, { PropTypes } from 'react';
// import { Panel, Input, Button } from 'react-bootstrap';
import Button from 'react-bootstrap/lib/Button';
import Panel from 'react-bootstrap/lib/Panel';
import { FormControl, Checkbox } from 'react-bootstrap';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import s from './OrderPage.css';
import history from '../../core/history';
const title = 'Order Creation';

function OrderPage(props, context) {
  alert("from order");
  context.setTitle(title);
  return (
    <div className="col-md-4 col-md-offset-4">
      


    </div>

  );
}

export default withStyles(s)(OrderPage);